// Home page button
let learnBtn = document.getElementById("learnMoreBtn");
if (learnBtn) {
    learnBtn.addEventListener("click", function() {
        alert("Explore our services and start your investment journey today!");
    });
}

// Contact form submission
let contactForm = document.getElementById("contactForm");
if (contactForm) {
    contactForm.addEventListener("submit", function(e) {
        e.preventDefault();
        document.getElementById("formMessage").innerText = "Thank you! Your message has been sent.";
        contactForm.reset();
    });
}